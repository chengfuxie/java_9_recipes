module com.oreilly.suppliers {
    exports com.oreilly.suppliers;
}