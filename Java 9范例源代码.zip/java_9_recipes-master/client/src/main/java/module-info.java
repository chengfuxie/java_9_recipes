module com.kousenit.clients {
    requires com.oreilly.suppliers;
}