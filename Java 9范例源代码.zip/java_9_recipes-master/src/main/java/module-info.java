module com.kousenit.recipes {
    requires jdk.incubator.httpclient;
}