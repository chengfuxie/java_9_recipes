package interfaces;

public class PrivateDemo implements SumNumbers {
}
