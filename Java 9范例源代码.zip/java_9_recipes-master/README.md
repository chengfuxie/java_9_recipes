# java_9_recipes
Source code for Java 9 chapter of Modern Java Recipes

http://shop.oreilly.com/product/0636920056669.do

Note: As of Apr 2018, tests have been ported to JUnit 5 and 
the code builds properly on Java 10.

Ken Kousen

